import { Component, OnInit, HostListener, AfterViewInit } from '@angular/core';
import { ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormArray, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';

import { CustomValidationService } from '../../services/custom-validation.service';


@Component({
  selector: 'app-proposal-form-new',
  templateUrl: './proposal-form-new.component.html',
  styleUrls: ['./proposal-form-new.component.css', '../common/ng-style/ng-style.component.css']
})

export class ProposalFormNewComponent implements OnInit {
  valueProgress = 10;
  btnClickCount=0;
  bufferValueProgress = 100;
  selectedItem = 'item1';
  color;
  mode;
  isFloat = true;
  footerVal
  currentPos: number;
  stepperVal=5;

  isComplete1
  isComplete2
  isComplete3
  isComplete4
  isComplete5
  isComplete6
  isStickyProgress:boolean=true;

  personalGroup: FormGroup;
  employmentGroup: FormGroup;
  historyGroup: FormGroup;
  medicalGroup: FormGroup;
  taxOtherGroup: FormGroup;
  childGroup: FormGroup;



  constructor(private router: Router, private fb: FormBuilder, private elem: ElementRef, public dialog: MatDialog, public cvserv : CustomValidationService) { }

  ngOnInit() {
    this.personalGroup = this.fb.group({
      policy: ['', Validators.required],
      nameTitle: ['',null],
      policyFor: ['child',[Validators.required]],
      fullName: ['',Validators.pattern(this.cvserv.HumanName)],
      dob: ['',Validators.pattern(this.cvserv.Date)],
      gender: ['', null],
      fName: ['', Validators.pattern(this.cvserv.HumanName)],
      mName: ['', Validators.pattern(this.cvserv.HumanName)],
      education: ['', null],
      isStudent: ['', null],
      classStudied: ['', Validators.pattern(this.cvserv.NumbersOnly)],
      parentInsuranceCoverd: ['', null],
      parentAnnualIncome: ['', null],
      sibInsuCover: ['', null],

      maritalStatus: ['', null],
      sName: ['', Validators.pattern(this.cvserv.HumanName)],
      nationality: ['', null],
      isIndia: ['', null],
      country: ['', null],
      currCountry: ['', null],
      employment: ['', null],
      addressline1: ['', Validators.pattern(this.cvserv.Address)],
      addressline2: ['', Validators.pattern(this.cvserv.Address)],
      contact: ['', Validators.pattern(this.cvserv.Phone)],
      emailId: ['', Validators.pattern(this.cvserv.Email)],
      equalPermentRecidencial: ['', null],
      address: ['', Validators.pattern(this.cvserv.Address)],
      city: ['', null],
      state: ['', null],
      pincode: ['', Validators.pattern(this.cvserv.Pincode)],


      nomineeName: ['', Validators.pattern(this.cvserv.HumanName)],
      nomineedob: ['', Validators.pattern(this.cvserv.Date)],
      relWithNomini: ['', null],
      nameOfAppointee: ['', Validators.pattern(this.cvserv.HumanName)],
      relOfAppointee: ['', Validators.pattern(this.cvserv.HumanName)],
      nominationPercentage: ['', null],

      // nomineeList: this.fb.array([
      //   this.initnomineeList(),
      // ]),

    });
    this.employmentGroup = this.fb.group({
      employee: ['', null],
    });
    this.historyGroup = this.fb.group({
      history: ['', null],
    });
    this.medicalGroup = this.fb.group({
      isAlcoholic: ['no', null],
      typeOfAddiction: ['', null],
      isTobbaco: ['', null],
      isAlcohol: ['', null],
      isAnyNarcotics: ['', null],
      tobaccoQuantity: ['', Validators.pattern(this.cvserv.NumbersOnly)],
      tobaccoSinceYears: ['', null],
      alcoholeQuantityPerDay: ['', Validators.pattern(this.cvserv.NumbersOnly)],
      alcoholeSinceYears: ['', null],
      narcoticsQuantity: ['', Validators.pattern(this.cvserv.NumbersOnly)],
      narcoticsSinceYears: ['', null],
      isStoppedConsumed: ['no', null],
      isAnyMedication: ['no', null],
      diseaseDiagnosed: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      dateOfDiagnosis: ['', Validators.pattern(this.cvserv.Date)],
      treatmentGiven: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      detailsOfMedicines: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      doctorName: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      followUpDate: ['', Validators.pattern(this.cvserv.Date)],
      anyComplications: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      addRemark: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      isReceivedTreatment: ['no', null],
      isUndergoneHospitalisation: ['no', null],
      isOtherHealthRelatedInformation: ['no', null],
      OtherHealthRelatedInformation: ['', Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      addRemark2: ['',  Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      durationSinceStopped: ['', null],
      sinceNoDays: ['',  Validators.pattern(this.cvserv.NumbersOnly)],
      reasonForDisc: ['',  Validators.pattern(this.cvserv.AlphaNumbersOnly)],
      diseaseList: ['', null],
      arePregnent: ['no', null],
      gynaecologicalComplications: ['no', null],
    });
    this.taxOtherGroup = this.fb.group({
      taxOther: ['', null],
    });
    this.childGroup = this.fb.group({
      nameTitleChild: ['', null],
      childfullName: ['', Validators.pattern(this.cvserv.HumanName)],
      childGender: ['', null],
      childDOB: ['', Validators.pattern(this.cvserv.Date)],
      maritalStatusChild: ['', null],
      childFName: ['', Validators.pattern(this.cvserv.HumanName)],
      ChildMName: ['', Validators.pattern(this.cvserv.HumanName)],
      childNationality: ['', null],
      educationChild: ['', null],
      isStudentChild: ['', null],
      classStudiedChild: ['',  Validators.pattern(this.cvserv.NumbersOnly)],
      
      parentInsuranceCoverdChild: ['', null],
      parentAnnualIncomeChild: ['', null],
      sibInsuCoverChild: ['', null],
      contactChild: ['', Validators.pattern(this.cvserv.Phone)],
      emailIdChild: ['', Validators.pattern(this.cvserv.Email)],
      address1: ['', Validators.pattern(this.cvserv.Address)],
      address2: ['', Validators.pattern(this.cvserv.Address)],
      childPincode: ['', Validators.pattern(this.cvserv.Pincode)],
      childCity: ['', null],
      childState: ['', null],
      isAddressSame: ['', null],
      isChildQue1: ['no', null],
      isChildQue2: ['no', null],
      isChildQue3: ['no', null],
      isChildQue4: ['no', null],
      isChildQue5: ['no', null],
      isChildQue6: ['no', null],
      isChildQue7: ['no', null],
      isChildQue8: ['no', null],
      isChildQue9: ['no', null],
      isChildQue10: ['no', null],
      addRemark1: ['',  Validators.pattern(this.cvserv.AlphaNumbersOnly)],

      physicianName: ['', Validators.pattern(this.cvserv.HumanName)],
      physicianAddress: ['', Validators.pattern(this.cvserv.Address)],
      physicianContactDetails: ['', Validators.pattern(this.cvserv.Phone)],
      HeightInFeet: ['', Validators.pattern(this.cvserv.NumbersOnly)],
      HeightInCm: ['cms', null],
      WeightInkgs: ['', null],
    });
  }

  @HostListener('window:scroll')
  checkScroll(): void {
    // let headerHeight = document.getElementsByTagName("header");
    // this.footerVal = document.getElementsByTagName("footer")[0].offsetTop;
    this.currentPos = window.pageYOffset;
    let currentPos1 = window.scrollY
    // console.log(currentPos1);


    // if ((window.innerHeight + window.scrollY) < (this.footerVal - 20)) {
    //   this.isFloat = true
    // } else {
    //   this.isFloat = false
    // }

    // if ((headerHeight[0].offsetHeight + 30) < window.scrollY) {
    //   document.getElementsByClassName("form-progress-wrapper")[0].classList.add("sticky-strpper");
    // }
    // else {
    //   document.getElementsByClassName("form-progress-wrapper")[0].classList.remove("sticky-strpper");
    // }
  }

  myFunction(elm, type) {
    let classListElm1 = elm.target;
    var matches1 = document.getElementsByClassName('inner-box');
    let innerBox = this.closest1(classListElm1,'.inner-box');
    let proposalDetails = this.closest1(classListElm1,'.proposal-details');

    if (type == "visited") {
      // console.log(111)
      innerBox.classList.remove("skipped");
      innerBox.classList.add("visited");

      var matches1 = document.getElementsByClassName('inner-box');

      for (var k = 0; k < matches1.length - 1; k++) {
        matches1[k].classList.remove('active');
      }


      if (innerBox.nextElementSibling != null && innerBox.nextElementSibling.classList[0]==='inner-box') {
        innerBox.nextElementSibling.classList.add("active");
      }
      else if (proposalDetails.nextElementSibling != null) {
        console.log(proposalDetails.nextElementSibling.children[0].children[0]);
        proposalDetails.nextElementSibling.children[0].children[0].classList.add("active")
      
      }

      // var z = innerBox.offsetTop;
      // document.getElementById("box-scroll").scroll({
      //   top: z + 50,
      //   behavior: 'smooth'
      // });


      // let el = document.getElementById('employment');
      innerBox.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});


    }

  }



  closest1(el, selector) {
    
    var matchesFn;

    // find vendor prefix
    ['matches','webkitMatchesSelector','mozMatchesSelector','msMatchesSelector','oMatchesSelector'].some(function(fn) {
        if (typeof document.body[fn] == 'function') {
            matchesFn = fn;
            return true;
        }
        return false;
    })

    var parent;

    // traverse parents
    while (el) {
        parent = el.parentElement;
        if (parent && parent[matchesFn](selector)) {
          // console.log(parent)
            return parent;
        }
       
        el = parent;
        // console.log(el)
    }

    return null;
}

  getScrollVal(ev){

    var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    let y = window.scrollY;
    
    if(isMobile){
      if(ev.target.scrollTop > 100){
        this.isStickyProgress=false;
      }else{
        this.isStickyProgress=true;
      }
    }

  }


  // 2nd function
  myFunction1(elm) {

    let classListElm = elm.target;
    var matches = document.getElementsByClassName('inner-box');
    let innerBox = this.closest1(classListElm,'.inner-box');
    let proposalDetails = this.closest1(classListElm,'.proposal-details');

    // console.log(111)
    // let classListElm = elm.target;
    // console.log(innerBox.classList.contains("active"))
    // var matches = document.getElementsByClassName('inner-box');
    // console.log(matches)

    if(innerBox.classList.contains("active")==false){
      for (var i = 0; i < matches.length; i++) {
        matches[i].classList.remove('active');
      }
      // innerBox.classList.remove("skipped");
      innerBox.classList.remove("visited");
      innerBox.classList.add("active");
    }
    


    

    // var z = classListElm.closest('.inner-box').offsetTop;
    // document.getElementById("box-scroll").scroll({
    //   top: z + 50,
    //   behavior: 'smooth'
    // });
  }

  getSelectVal(e){
    
  }

  onValChange(e){
    if (this.personalGroup.value.policy == 'no') {
      this.stepperVal = 6;
    }else{
      this.stepperVal = 5;
    }
  }

  getProgress(val){
    this.valueProgress = 20;
    let progressPer = 100 / this.stepperVal;
    this.valueProgress = progressPer * (val+1);

    // let progressPer = 100 / this.stepperVal;
    // if(this.valueProgress < 100){
    //   // this.valueProgress = progressPer + this.valueProgress ;
    //   this.valueProgress = progressPer * val;
    //   alert(this.valueProgress)
    // }
  }

  getSave(val){

    this.getProgress(val);
    // this.valueProgress = 0;
    // alert(this.valueProgress)

    if(val==1){
      
      this.selectedItem='item2';

      let el = document.getElementById('employment');
      el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});

      if (this.personalGroup.valid) {
        this.isComplete1 = 'complited';
      } else {
        this.isComplete1 = "incomplete";
      }
    }
    
    else if(val==2 )
    {
     
      this.selectedItem='item3';
      let el = document.getElementById('history');
      el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
      
      if (this.employmentGroup.valid) {
        this.isComplete2 = 'complited';
      } else {
        this.isComplete2 = "incomplete";
      }

    }
    else if(val==3)
    {
      
      this.selectedItem='item4';
      let el = document.getElementById('medical');
      el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
     
      if (this.historyGroup.valid) {
        this.isComplete3 = 'complited';
      } else {
        this.isComplete3 = "incomplete";
      }

    }
    else if(val==4)
   { 
    
     this.selectedItem='item5';
     let el = document.getElementById('taxOther');
     el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
    
      if (this.medicalGroup.valid) {
        this.isComplete4 = 'complited';
      } else {
        this.isComplete4 = "incomplete";
      }

    }
    else if(val==5) 
    {
      
      if(this.personalGroup.value.policy=='no'){
        this.selectedItem='item6';
        let el = document.getElementById('child');
        el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
      }
     
     
     if (this.taxOtherGroup.valid) {
        this.isComplete5 = 'complited';
      } else {
        this.isComplete5 = "incomplete";
      }

    }

    else if(val==6)
    {
      // this.selectedItem='item6';
    //   let el = document.getElementById('child');
    //  el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
     
     if (this.childGroup.valid) {
        this.isComplete6 = 'complited';
        // this.valueProgress= 100;
      } else {
        this.isComplete6 = "incomplete";
      }

    }

    
  }

}
