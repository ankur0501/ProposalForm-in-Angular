import { PersonalDetail } from './personal-detail';

describe('PersonalDetail', () => {
  it('should create an instance', () => {
    expect(new PersonalDetail()).toBeTruthy();
  });
});
