import { CustomFilterPipe } from './custom-filter.pipe';

describe('CustomFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CustomFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
