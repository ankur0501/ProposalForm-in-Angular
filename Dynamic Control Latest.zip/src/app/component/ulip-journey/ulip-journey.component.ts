import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ulip-journey',
  templateUrl: './ulip-journey.component.html',
  styleUrls: ['./ulip-journey.component.css','../common/ng-style/ng-style.component.css']
})
export class UlipJourneyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
